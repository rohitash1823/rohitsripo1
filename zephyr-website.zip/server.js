const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const url = require('url');

const PORT = 3000;
const DATA_DIR = path.join(__dirname, 'data');
const PUBLIC_DIR = path.join(__dirname, 'public');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const USERS_FILE = path.join(DATA_DIR, 'users.json');
const ORDERS_FILE = path.join(DATA_DIR, 'orders.json');
const JWT_SECRET = 'zephyr_elegant_secret_2026';

const COUPONS = {
  ZEPHYRCOST: 99,
  ZEPHRIDE: 125,
  ZEPHZERO: 165
};

function readJSON(file, def = []) {
  try {
    if (fs.existsSync(file)) return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (e) {}
  return def;
}

function writeJSON(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function uuid() {
  return crypto.randomUUID ? crypto.randomUUID() : crypto.randomBytes(16).toString('hex');
}

function hashPassword(pw) {
  return crypto.createHash('sha256').update(pw + JWT_SECRET).digest('hex');
}

function signToken(payload) {
  const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
  const body = Buffer.from(JSON.stringify({ ...payload, exp: Date.now() + 7 * 86400000 })).toString('base64url');
  const sig = crypto.createHmac('sha256', JWT_SECRET).update(header + '.' + body).digest('base64url');
  return header + '.' + body + '.' + sig;
}

function verifyToken(token) {
  try {
    const [header, body, sig] = token.split('.');
    const expected = crypto.createHmac('sha256', JWT_SECRET).update(header + '.' + body).digest('base64url');
    if (sig !== expected) return null;
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString());
    if (payload.exp < Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}

function parseBody(req) {
  return new Promise((resolve) => {
    let data = '';
    req.on('data', chunk => data += chunk);
    req.on('end', () => {
      try { resolve(JSON.parse(data || '{}')); }
      catch { resolve({}); }
    });
  });
}

function send(res, status, data) {
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
  });
  res.end(JSON.stringify(data));
}

function serveStatic(req, res) {
  let filePath = path.join(PUBLIC_DIR, req.url === '/' ? 'index.html' : req.url.split('?')[0]);
  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403); res.end(); return;
  }
  const ext = path.extname(filePath).toLowerCase();
  const types = { '.html': 'text/html', '.css': 'text/css', '.js': 'application/javascript', '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml' };
  fs.readFile(filePath, (err, content) => {
    if (err) {
      fs.readFile(path.join(PUBLIC_DIR, 'index.html'), (e2, html) => {
        if (e2) { res.writeHead(404); res.end('Not found'); return; }
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(html);
      });
      return;
    }
    res.writeHead(200, { 'Content-Type': types[ext] || 'text/plain' });
    res.end(content);
  });
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
    });
    res.end();
    return;
  }

  const parsed = url.parse(req.url, true);
  const pathname = parsed.pathname;

  if (pathname === '/api/health') {
    return send(res, 200, { status: 'ZEPHYR server running' });
  }

  if (pathname === '/api/signup' && req.method === 'POST') {
    const body = await parseBody(req);
    if (!body.email || !body.password) return send(res, 400, { error: 'Email and password required' });
    const users = readJSON(USERS_FILE);
    if (users.find(u => u.email === body.email)) return send(res, 400, { error: 'Email already registered' });
    const user = {
      id: uuid(),
      name: body.name || body.email.split('@')[0],
      email: body.email,
      password: hashPassword(body.password),
      google: false,
      createdAt: new Date().toISOString()
    };
    users.push(user);
    writeJSON(USERS_FILE, users);
    const token = signToken({ id: user.id, email: user.email, name: user.name });
    return send(res, 200, { token, user: { id: user.id, name: user.name, email: user.email } });
  }

  if (pathname === '/api/login' && req.method === 'POST') {
    const body = await parseBody(req);
    const users = readJSON(USERS_FILE);
    const user = users.find(u => u.email === body.email);
    if (!user || user.password !== hashPassword(body.password || '')) {
      return send(res, 400, { error: 'Invalid credentials' });
    }
    const token = signToken({ id: user.id, email: user.email, name: user.name });
    return send(res, 200, { token, user: { id: user.id, name: user.name, email: user.email } });
  }

  if (pathname === '/api/google-auth' && req.method === 'POST') {
    const body = await parseBody(req);
    if (!body.email) return send(res, 400, { error: 'Email required' });
    let users = readJSON(USERS_FILE);
    let user = users.find(u => u.email === body.email);
    if (!user) {
      user = {
        id: uuid(),
        name: body.name || body.email.split('@')[0],
        email: body.email,
        password: null,
        google: true,
        createdAt: new Date().toISOString()
      };
      users.push(user);
      writeJSON(USERS_FILE, users);
    }
    const token = signToken({ id: user.id, email: user.email, name: user.name });
    return send(res, 200, { token, user: { id: user.id, name: user.name, email: user.email } });
  }

  if (pathname === '/api/validate-coupon' && req.method === 'POST') {
    const body = await parseBody(req);
    const upper = (body.code || '').toUpperCase().trim();
    if (COUPONS[upper] !== undefined) {
      return send(res, 200, { valid: true, discount: COUPONS[upper], code: upper });
    }
    return send(res, 200, { valid: false, message: 'Invalid coupon code' });
  }

  if (pathname === '/api/orders' && req.method === 'POST') {
    const authHeader = req.headers.authorization || '';
    const token = authHeader.replace('Bearer ', '');
    const payload = verifyToken(token);
    if (!payload) return send(res, 401, { error: 'Unauthorized' });
    const body = await parseBody(req);
    const order = {
      id: uuid(),
      userId: payload.id,
      userEmail: payload.email,
      userName: payload.name,
      ...body,
      status: 'issued',
      createdAt: new Date().toISOString()
    };
    const orders = readJSON(ORDERS_FILE);
    orders.push(order);
    writeJSON(ORDERS_FILE, orders);

    const whatsappMessage = encodeURIComponent(
`ZEPHYR Order Issued ✅
Order ID: ${order.id}
Customer: ${order.userName} (${order.userEmail})
Type: ${order.cardType}
Quantity: ${order.quantity}
Name on Card: ${order.cardName || 'N/A'}
Color: ${order.cardColor}
Metallic: ${order.metallic ? 'Yes' : 'No'}
Name Style: ${order.nameStyle}
Print Style: ${order.printStyle}
Text Color: ${order.textColor}
Price per card: ₹${order.unitPrice}
Delivery: ₹${order.delivery}
Coupon: ${order.couponCode || 'None'} (₹${order.couponDiscount || 0})
Total: ₹${order.total}
Payment: ${order.paymentMethod}
Time: ${order.createdAt}`
    );

    console.log('ORDER ISSUED → WhatsApp 7769857023');
    console.log(JSON.stringify(order, null, 2));

    return send(res, 200, { success: true, order, whatsappMessage });
  }

  if (pathname === '/api/orders' && req.method === 'GET') {
    const authHeader = req.headers.authorization || '';
    const token = authHeader.replace('Bearer ', '');
    const payload = verifyToken(token);
    if (!payload) return send(res, 401, { error: 'Unauthorized' });
    const orders = readJSON(ORDERS_FILE);
    const userOrders = orders.filter(o => o.userId === payload.id).reverse();
    return send(res, 200, userOrders);
  }

  serveStatic(req, res);
});

server.listen(PORT, () => {
  console.log(`ZEPHYR elegant server running at http://localhost:${PORT}`);
});
