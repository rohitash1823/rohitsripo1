const API = window.location.origin;

// State
let state = {
  user: null,
  token: localStorage.getItem('zephyr_token'),
  authMode: 'signup', // signup | login
  cardType: 'personal',
  cardColor: '#1a1a1a',
  textColor: '#f5f0e8',
  metallic: false,
  nameStyle: 'elegant',
  printStyle: 'classic',
  quantity: 1,
  coupon: null,
  couponDiscount: 0,
  paymentMethod: null,
  orderReady: false
};

const BASE_PRICE = 499;
const DELIVERY = 217;
const VOLUME_DISCOUNT_PER = 29; // per card after 1, up to 5 cards
const COLORS = [
  { name: 'Obsidian', hex: '#1a1a1a' },
  { name: 'Midnight', hex: '#0f172a' },
  { name: 'Charcoal', hex: '#2d2d2d' },
  { name: 'Navy', hex: '#1e3a5f' },
  { name: 'Forest', hex: '#1a2f23' },
  { name: 'Burgundy', hex: '#4a1c24' },
  { name: 'Slate', hex: '#334155' },
  { name: 'Gold', hex: '#8a7335' },
  { name: 'Rose', hex: '#4a3040' },
  { name: 'Ivory', hex: '#e8e0d5' },
  { name: 'Pearl', hex: '#f0ebe3' },
  { name: 'Steel', hex: '#4a5568' }
];

// Init
document.addEventListener('DOMContentLoaded', () => {
  initColors();
  initCardRotation();
  updateCardPreview();
  recalcBill();
  if (state.token) {
    try {
      const payload = JSON.parse(atob(state.token.split('.')[1]));
      state.user = { id: payload.id, email: payload.email, name: payload.name };
      updateAuthUI();
    } catch {
      localStorage.removeItem('zephyr_token');
      state.token = null;
    }
  }
  // Enable proceed when name filled
  document.getElementById('cardName').addEventListener('input', () => {
    const name = document.getElementById('cardName').value.trim();
    document.getElementById('btnProceedOrder').disabled = !name;
  });
});

function initColors() {
  const grid = document.getElementById('colorGrid');
  COLORS.forEach((c, i) => {
    const btn = document.createElement('button');
    btn.className = 'color-swatch' + (i === 0 ? ' active' : '');
    btn.style.background = c.hex;
    btn.title = c.name;
    btn.onclick = () => {
      document.querySelectorAll('.color-swatch').forEach(s => s.classList.remove('active'));
      btn.classList.add('active');
      state.cardColor = c.hex;
      document.getElementById('customColor').value = c.hex;
      updateCardPreview();
    };
    grid.appendChild(btn);
  });
}

function selectCustomColor(hex) {
  state.cardColor = hex;
  document.querySelectorAll('.color-swatch').forEach(s => s.classList.remove('active'));
  updateCardPreview();
}

function selectTextColor(hex) {
  state.textColor = hex;
  document.querySelectorAll('.text-color-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.color === hex);
  });
  updateCardPreview();
}

function selectCardType(type) {
  state.cardType = type;
  document.querySelectorAll('.type-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.type === type);
  });
  const max = type === 'personal' ? 10 : 100;
  const qtyInput = document.getElementById('quantity');
  qtyInput.max = max;
  if (parseInt(qtyInput.value) > max) qtyInput.value = max;
  document.getElementById('qtyLimitHint').textContent = `(max ${max} for ${type})`;
  state.quantity = parseInt(qtyInput.value) || 1;
  recalcBill();
}

function updateCardPreview() {
  const name = document.getElementById('cardName').value.trim() || 'Your Name';
  const title = document.getElementById('cardTitle').value.trim();
  state.nameStyle = document.getElementById('nameStyle').value;
  state.printStyle = document.getElementById('printStyle').value;
  state.metallic = document.getElementById('metallic').checked;
  state.quantity = parseInt(document.getElementById('quantity').value) || 1;

  const front = document.getElementById('cardFront');
  const back = document.getElementById('cardBack');
  const card3d = document.getElementById('card3d');

  // Colors
  front.style.background = state.metallic
    ? `linear-gradient(135deg, ${lighten(state.cardColor, 30)} 0%, ${state.cardColor} 25%, ${lighten(state.cardColor, 40)} 50%, ${state.cardColor} 75%, ${lighten(state.cardColor, 20)} 100%)`
    : `linear-gradient(145deg, ${lighten(state.cardColor, 12)}, ${state.cardColor})`;
  front.style.backgroundSize = state.metallic ? '200% 200%' : 'auto';
  if (state.metallic) front.style.animation = 'metallicShine 4s ease infinite';
  else front.style.animation = 'none';

  back.style.background = `linear-gradient(145deg, ${darken(state.cardColor, 10)}, ${state.cardColor})`;

  // Text
  document.getElementById('previewName').textContent = name;
  document.getElementById('previewName').style.color = state.textColor;
  document.getElementById('previewTitle').textContent = title;
  document.getElementById('previewTitle').style.color = state.textColor;
  document.getElementById('previewTitle').style.opacity = '0.75';

  // Classes for style
  card3d.className = 'card-3d';
  card3d.classList.add(`name-style-${state.nameStyle}`);
  card3d.classList.add(`print-${state.printStyle}`);
  if (state.metallic) card3d.classList.add('metallic');

  // Hero card sync lightly
  const hero = document.getElementById('heroCard');
  if (hero) {
    hero.querySelector('.card-name').textContent = name === 'Your Name' ? 'Alex Rivera' : name;
  }
}

function lighten(hex, percent) {
  const num = parseInt(hex.replace('#', ''), 16);
  const r = Math.min(255, (num >> 16) + percent);
  const g = Math.min(255, ((num >> 8) & 0x00FF) + percent);
  const b = Math.min(255, (num & 0x0000FF) + percent);
  return `#${(r << 16 | g << 8 | b).toString(16).padStart(6, '0')}`;
}

function darken(hex, percent) {
  const num = parseInt(hex.replace('#', ''), 16);
  const r = Math.max(0, (num >> 16) - percent);
  const g = Math.max(0, ((num >> 8) & 0x00FF) - percent);
  const b = Math.max(0, (num & 0x0000FF) - percent);
  return `#${(r << 16 | g << 8 | b).toString(16).padStart(6, '0')}`;
}

// 3D rotation
function initCardRotation() {
  const scene = document.getElementById('cardScene');
  const card = document.getElementById('card3d');
  let isDragging = false;
  let startX, startY;
  let rotY = -15;
  let rotX = 8;

  card.style.transform = `rotateY(${rotY}deg) rotateX(${rotX}deg)`;

  scene.addEventListener('mousedown', e => {
    isDragging = true;
    startX = e.clientX;
    startY = e.clientY;
  });
  window.addEventListener('mouseup', () => { isDragging = false; });
  window.addEventListener('mousemove', e => {
    if (!isDragging) return;
    const dx = e.clientX - startX;
    const dy = e.clientY - startY;
    rotY += dx * 0.4;
    rotX -= dy * 0.3;
    rotX = Math.max(-30, Math.min(30, rotX));
    card.style.transform = `rotateY(${rotY}deg) rotateX(${rotX}deg)`;
    startX = e.clientX;
    startY = e.clientY;
  });

  // Touch
  scene.addEventListener('touchstart', e => {
    isDragging = true;
    startX = e.touches[0].clientX;
    startY = e.touches[0].clientY;
  }, { passive: true });
  window.addEventListener('touchend', () => { isDragging = false; });
  window.addEventListener('touchmove', e => {
    if (!isDragging) return;
    const dx = e.touches[0].clientX - startX;
    const dy = e.touches[0].clientY - startY;
    rotY += dx * 0.4;
    rotX -= dy * 0.3;
    rotX = Math.max(-30, Math.min(30, rotX));
    card.style.transform = `rotateY(${rotY}deg) rotateX(${rotX}deg)`;
    startX = e.touches[0].clientX;
    startY = e.touches[0].clientY;
  }, { passive: true });
}

// Pricing
function calcPrices() {
  const qty = Math.max(1, state.quantity || 1);
  let unit = BASE_PRICE;
  // Reduce 29 per card for each additional card up to 5 total
  // e.g. qty 1: 499, qty 2: 499-29, ..., qty 5+: 499-29*4
  const discountSteps = Math.min(qty - 1, 4); // max 4 reductions (for 5 cards)
  const volumeDiscountPerCard = discountSteps * VOLUME_DISCOUNT_PER;
  unit = BASE_PRICE - volumeDiscountPerCard;
  const subtotal = unit * qty;
  const volumeTotalDiscount = volumeDiscountPerCard * qty;
  let delivery = DELIVERY;
  // slight delivery note already in UI
  let couponDisc = state.couponDiscount || 0;
  const total = Math.max(0, subtotal + delivery - couponDisc);
  return { unit, subtotal, delivery, volumeTotalDiscount, couponDisc, total, qty };
}

function recalcBill() {
  state.quantity = parseInt(document.getElementById('quantity').value) || 1;
  const p = calcPrices();
  document.getElementById('billType').textContent = state.cardType === 'personal' ? 'Personal' : 'Business';
  document.getElementById('billQty').textContent = p.qty;
  document.getElementById('billUnit').textContent = `₹${p.unit}`;
  document.getElementById('billSub').textContent = `₹${p.subtotal}`;
  document.getElementById('billDelivery').textContent = `₹${p.delivery}`;
  if (p.volumeTotalDiscount > 0) {
    document.getElementById('billDiscountRow').style.display = 'flex';
    document.getElementById('billDiscount').textContent = `-₹${p.volumeTotalDiscount}`;
  } else {
    document.getElementById('billDiscountRow').style.display = 'none';
  }
  if (p.couponDisc > 0) {
    document.getElementById('billCouponRow').style.display = 'flex';
    document.getElementById('billCoupon').textContent = `-₹${p.couponDisc}`;
  } else {
    document.getElementById('billCouponRow').style.display = 'none';
  }
  document.getElementById('billTotal').textContent = `₹${p.total}`;
}

function showOrderPanel() {
  if (!state.user) {
    openAuth('login');
    return;
  }
  const name = document.getElementById('cardName').value.trim();
  if (!name) {
    alert('Please enter the name for the card.');
    return;
  }
  document.getElementById('orderPanel').classList.remove('hidden');
  recalcBill();
  document.getElementById('orderPanel').scrollIntoView({ behavior: 'smooth' });
}

async function applyCoupon() {
  const code = document.getElementById('couponInput').value.trim();
  const msg = document.getElementById('couponMsg');
  if (!code) {
    msg.textContent = 'Enter a coupon code';
    msg.className = 'coupon-msg invalid';
    return;
  }
  try {
    const res = await fetch(`${API}/api/validate-coupon`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code })
    });
    const data = await res.json();
    if (data.valid) {
      state.coupon = data.code;
      state.couponDiscount = data.discount;
      msg.textContent = `Coupon ${data.code} applied! −₹${data.discount}`;
      msg.className = 'coupon-msg valid';
      recalcBill();
      // Enable order only after valid coupon? User said: show order option below bill only after coupon correct otherwise say pay original
      // We always show the button; message guides.
    } else {
      state.coupon = null;
      state.couponDiscount = 0;
      msg.textContent = 'Invalid coupon code. Pay original bill without coupon.';
      msg.className = 'coupon-msg invalid';
      recalcBill();
    }
  } catch (e) {
    // Offline fallback
    const upper = code.toUpperCase();
    const map = { ZEPHYRCOST: 99, ZEPHRIDE: 125, ZEPHZERO: 165 };
    if (map[upper]) {
      state.coupon = upper;
      state.couponDiscount = map[upper];
      msg.textContent = `Coupon ${upper} applied! −₹${map[upper]}`;
      msg.className = 'coupon-msg valid';
    } else {
      state.coupon = null;
      state.couponDiscount = 0;
      msg.textContent = 'Invalid coupon code. Pay original bill without coupon.';
      msg.className = 'coupon-msg invalid';
    }
    recalcBill();
  }
}

function selectPayment(btn) {
  document.querySelectorAll('.pay-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  state.paymentMethod = btn.dataset.method;
  document.getElementById('btnPlaceOrder').disabled = false;
}

async function placeOrder() {
  if (!state.user || !state.token) {
    openAuth('login');
    return;
  }
  if (!state.paymentMethod) {
    alert('Please select a payment method');
    return;
  }
  const p = calcPrices();
  const orderData = {
    cardType: state.cardType,
    cardName: document.getElementById('cardName').value.trim(),
    cardTitle: document.getElementById('cardTitle').value.trim(),
    cardColor: state.cardColor,
    metallic: state.metallic,
    nameStyle: state.nameStyle,
    printStyle: state.printStyle,
    textColor: state.textColor,
    quantity: p.qty,
    unitPrice: p.unit,
    subtotal: p.subtotal,
    delivery: p.delivery,
    volumeDiscount: p.volumeTotalDiscount,
    couponCode: state.coupon,
    couponDiscount: p.couponDisc,
    total: p.total,
    paymentMethod: state.paymentMethod
  };

  const statusEl = document.getElementById('orderStatus');
  statusEl.textContent = 'Processing payment...';
  statusEl.style.color = 'var(--gold)';

  try {
    const res = await fetch(`${API}/api/orders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${state.token}`
      },
      body: JSON.stringify(orderData)
    });
    const data = await res.json();
    if (data.success) {
      // Open WhatsApp with details
      const waUrl = `https://wa.me/917769857023?text=${data.whatsappMessage}`;
      window.open(waUrl, '_blank');

      document.getElementById('successOrderId').textContent = data.order.id.slice(0, 8).toUpperCase();
      document.getElementById('successModal').classList.remove('hidden');
      statusEl.textContent = '';
      // Reset form partially
      document.getElementById('orderPanel').classList.add('hidden');
    } else {
      statusEl.textContent = data.error || 'Order failed';
      statusEl.style.color = 'var(--danger)';
    }
  } catch (e) {
    // Fallback: still open WhatsApp
    const msg = encodeURIComponent(
`ZEPHYR Order (offline)
Name: ${orderData.cardName}
Type: ${orderData.cardType}
Qty: ${orderData.quantity}
Color: ${orderData.cardColor}
Metallic: ${orderData.metallic}
Style: ${orderData.nameStyle} / ${orderData.printStyle}
Text: ${orderData.textColor}
Total: ₹${orderData.total}
Payment: ${orderData.paymentMethod}`
    );
    window.open(`https://wa.me/917769857023?text=${msg}`, '_blank');
    document.getElementById('successOrderId').textContent = 'LOCAL-' + Date.now().toString(36).toUpperCase();
    document.getElementById('successModal').classList.remove('hidden');
    statusEl.textContent = '';
  }
}

function closeSuccess() {
  document.getElementById('successModal').classList.add('hidden');
  showPage('orders');
  loadOrders();
}

// Auth
function openAuth(mode) {
  state.authMode = mode;
  document.getElementById('authModal').classList.remove('hidden');
  updateAuthForm();
}

function closeAuth() {
  document.getElementById('authModal').classList.add('hidden');
  document.getElementById('authError').textContent = '';
}

function toggleAuthMode(e) {
  e.preventDefault();
  state.authMode = state.authMode === 'signup' ? 'login' : 'signup';
  updateAuthForm();
}

function updateAuthForm() {
  const isSignup = state.authMode === 'signup';
  document.getElementById('authTitle').textContent = isSignup ? 'Create Account' : 'Welcome Back';
  document.getElementById('authName').parentElement.style.display = isSignup ? 'block' : 'none';
  document.getElementById('authSubmit').textContent = isSignup ? 'Sign Up' : 'Login';
  document.getElementById('authSwitchText').textContent = isSignup ? 'Already have an account?' : 'New to ZEPHYR?';
  document.getElementById('authSwitchLink').textContent = isSignup ? 'Login' : 'Sign Up';
  document.getElementById('authError').textContent = '';
}

function togglePassword() {
  const input = document.getElementById('authPassword');
  const btn = document.querySelector('.show-pass');
  if (input.type === 'password') {
    input.type = 'text';
    btn.textContent = 'Hide';
  } else {
    input.type = 'password';
    btn.textContent = 'Show';
  }
}

async function submitAuth() {
  const email = document.getElementById('authEmail').value.trim();
  const password = document.getElementById('authPassword').value;
  const name = document.getElementById('authName').value.trim();
  const err = document.getElementById('authError');
  if (!email || !password) {
    err.textContent = 'Email and password required';
    return;
  }
  try {
    const endpoint = state.authMode === 'signup' ? '/api/signup' : '/api/login';
    const body = state.authMode === 'signup' ? { name, email, password } : { email, password };
    const res = await fetch(`${API}${endpoint}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    const data = await res.json();
    if (data.token) {
      state.token = data.token;
      state.user = data.user;
      localStorage.setItem('zephyr_token', data.token);
      updateAuthUI();
      closeAuth();
    } else {
      err.textContent = data.error || 'Authentication failed';
    }
  } catch (e) {
    // Offline demo mode
    state.user = { id: 'local', name: name || email.split('@')[0], email };
    state.token = 'local-demo-token';
    localStorage.setItem('zephyr_token', state.token);
    updateAuthUI();
    closeAuth();
  }
}

async function googleAuth() {
  // Simulated Google: prompt for email or use a demo
  const email = prompt('Enter your Google email for demo (or leave blank for demo@zephyr.app):') || 'demo@zephyr.app';
  const name = email.split('@')[0].replace(/[._]/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
  try {
    const res = await fetch(`${API}/api/google-auth`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, name })
    });
    const data = await res.json();
    if (data.token) {
      state.token = data.token;
      state.user = data.user;
      localStorage.setItem('zephyr_token', data.token);
      updateAuthUI();
      closeAuth();
    } else {
      document.getElementById('authError').textContent = data.error || 'Google auth failed';
    }
  } catch {
    state.user = { id: 'google-local', name, email };
    state.token = 'google-demo-token';
    localStorage.setItem('zephyr_token', state.token);
    updateAuthUI();
    closeAuth();
  }
}

function updateAuthUI() {
  if (state.user) {
    document.getElementById('btnLogin').style.display = 'none';
    document.getElementById('btnSignup').style.display = 'none';
    document.getElementById('userMenu').style.display = 'flex';
    document.getElementById('userName').textContent = state.user.name;
    document.getElementById('navOrders').style.display = 'inline';
  } else {
    document.getElementById('btnLogin').style.display = 'inline-block';
    document.getElementById('btnSignup').style.display = 'inline-block';
    document.getElementById('userMenu').style.display = 'none';
    document.getElementById('navOrders').style.display = 'none';
  }
}

function logout() {
  state.user = null;
  state.token = null;
  localStorage.removeItem('zephyr_token');
  updateAuthUI();
  showPage('home');
}

// Pages
function showPage(id) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById('page-' + id).classList.add('active');
  if (id === 'orders') loadOrders();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

async function loadOrders() {
  const list = document.getElementById('ordersList');
  if (!state.user || !state.token) {
    list.innerHTML = '<p class="empty">Sign in to view your orders.</p>';
    return;
  }
  list.innerHTML = '<p class="empty">Loading...</p>';
  try {
    const res = await fetch(`${API}/api/orders`, {
      headers: { 'Authorization': `Bearer ${state.token}` }
    });
    const orders = await res.json();
    if (!orders.length) {
      list.innerHTML = '<p class="empty">No orders yet. Customize and order your first Zecard!</p>';
      return;
    }
    list.innerHTML = orders.map(o => `
      <div class="order-item">
        <h4>${o.cardName || 'Zecard'} — ${o.cardType}</h4>
        <div class="order-meta">
          <span>Qty: ${o.quantity}</span>
          <span>Total: ₹${o.total}</span>
          <span>${o.paymentMethod}</span>
          <span>${new Date(o.createdAt).toLocaleDateString()}</span>
          <span style="color:var(--success)">● ${o.status}</span>
        </div>
        <div class="order-meta" style="margin-top:0.4rem">
          <span>Color: ${o.cardColor}</span>
          <span>${o.metallic ? 'Metallic' : 'Matte'}</span>
          <span>${o.nameStyle} / ${o.printStyle}</span>
        </div>
      </div>
    `).join('');
  } catch {
    list.innerHTML = '<p class="empty">Could not load orders. Server may be offline.</p>';
  }
}
